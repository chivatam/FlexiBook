/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.30.1.5099.60569f335 modeling language!*/



// line 2 "model.ump"
// line 61 "model.ump"
public class FlexiBook
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public FlexiBook()
  {}

  //------------------------
  // INTERFACE
  //------------------------

  public void delete()
  {}

}