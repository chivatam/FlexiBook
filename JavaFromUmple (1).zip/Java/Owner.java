/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.30.1.5099.60569f335 modeling language!*/



// line 18 "model.ump"
// line 76 "model.ump"
public class Owner
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Owner()
  {}

  //------------------------
  // INTERFACE
  //------------------------

  public void delete()
  {}

}